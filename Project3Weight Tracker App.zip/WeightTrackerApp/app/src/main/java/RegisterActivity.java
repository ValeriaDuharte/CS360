package com.example.weighttrackerapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText usernameInput, passwordInput;
    Button registerBtn;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DatabaseHelper(this);

        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        registerBtn = findViewById(R.id.registerBtn);

        registerBtn.setOnClickListener(v -> {
            String user = usernameInput.getText().toString();
            String pass = passwordInput.getText().toString();

            if(db.registerUser(user, pass)) {
                Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Username Exists", Toast.LENGTH_SHORT).show();
            }
        });
    }
}