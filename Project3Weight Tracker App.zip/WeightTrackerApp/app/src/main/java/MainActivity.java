package com.example.weighttrackerapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.database.Cursor;
import android.content.pm.PackageManager;
import android.Manifest;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity {

    EditText weightInput, dateInput;
    Button addEntryBtn;
    LinearLayout entriesContainer;
    DatabaseHelper db;

    private static final int SMS_PERMISSION_CODE = 100;
    private double GOAL_WEIGHT = 150; // Example goal

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        weightInput = findViewById(R.id.weightInput);
        dateInput = findViewById(R.id.dateInput);
        addEntryBtn = findViewById(R.id.addEntryBtn);
        entriesContainer = findViewById(R.id.entriesContainer);

        loadEntries();

        addEntryBtn.setOnClickListener(v -> {
            String date = dateInput.getText().toString();
            String weightStr = weightInput.getText().toString();

            if(date.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Enter date and weight", Toast.LENGTH_SHORT).show();
                return;
            }

            double weight;
            try { weight = Double.parseDouble(weightStr); }
            catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
                return;
            }

            if(db.addWeight(weight, date)) {
                Toast.makeText(this, "Entry Added", Toast.LENGTH_SHORT).show();
                weightInput.setText(""); dateInput.setText("");
                loadEntries();

                // Send SMS if goal reached
                if(weight <= GOAL_WEIGHT) sendSMS("Congrats! You reached your goal weight: " + weight + " lbs");
            } else {
                Toast.makeText(this, "Error adding entry", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadEntries() {
        entriesContainer.removeAllViews();
        Cursor cursor = db.getAllWeights();
        if(cursor != null && cursor.getCount() > 0) {
            while(cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(8,8,8,8);
                row.setGravity(Gravity.CENTER_VERTICAL);

                TextView dateText = new TextView(this);
                dateText.setText(date);
                dateText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
                row.addView(dateText);

                TextView weightText = new TextView(this);
                weightText.setText(weight + " lbs");
                weightText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
                row.addView(weightText);

                Button deleteBtn = new Button(this);
                deleteBtn.setText("Delete");
                deleteBtn.setBackgroundColor(Color.parseColor("#2196F3"));
                deleteBtn.setTextColor(Color.WHITE);
                deleteBtn.setOnClickListener(view -> {
                    db.deleteWeight(id);
                    Toast.makeText(this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                    loadEntries();
                });
                row.addView(deleteBtn);

                entriesContainer.addView(row);
            }
            cursor.close();
        }
    }

    private void sendSMS(String message) {
        // Check permission
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            return;
        }
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage("5551234567", null, message, null, null); // Replace with user's number
            Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();
        } catch(Exception e) {
            Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}